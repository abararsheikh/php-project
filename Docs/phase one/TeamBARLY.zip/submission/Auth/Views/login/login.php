<?php
/**
 * @Author Yi Zhao
 *
 */

?>
<script>System.import('/Auth/Views/login/app.jsx!')</script>
<div id="login"></div>
