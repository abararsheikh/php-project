import React from 'react';
import ReactDOM from 'react-dom';
import LoginApp from './components/LoginApp.jsx!'

ReactDOM.render(
    <LoginApp />,
    document.querySelector('#login')
);